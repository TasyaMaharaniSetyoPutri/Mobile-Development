package com.tasya.hitungumur

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnHitung.setOnClickListener {

            //Deklarasi edit text
            val tahunLahir = etInputUmur.text.toString()

            //get tahun saat ini dengan calender
            val tahun: Int = Calendar.getInstance().get(Calendar.YEAR)

            //set umur = tahun saat ini dikurang dengan input pada text
            var umur = 0
            if (tahunLahir.toIntOrNull() != null) {
                umur = tahun - tahunLahir.toInt()
                tvUmur.text = "Umur = $umur Tahun"
            } else {
                tvUmur.text = "Tahun Tidak Valid"
            }
        }
    }
}
